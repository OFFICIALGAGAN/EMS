﻿using System.ComponentModel.DataAnnotations;

namespace EMS.Models
{

        public class Employee
        {
            public int ID { get; set; } 
            public string Name { get; set; }
            public string Email { get; set; }
            public string Address { get; set; }
            public string Phone { get; set; }
            public decimal Salary { get; set; }
            public string Gender { get; set; }
            public string State { get; set; }
            public DateTime DateOfJoin { get; set; }
            public DateTime DateOfBirth { get; set; }
            public int Age { get; set; } 

         
            public Employee() { }

    
            public Employee(int id, string name, string email, string address, string phone, decimal salary, string gender, string state, DateTime dateOfJoin, DateTime dateOfBirth, int age)
            {
                ID = id;
                Name = name;
                Email = email;
                Address = address;
                Phone = phone;
                Salary = salary;
                Gender = gender;
                State = state;
                DateOfJoin = dateOfJoin;
                DateOfBirth = dateOfBirth;
                Age = age;
            }
        }
    }

