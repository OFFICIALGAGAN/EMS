﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using EMS.DBContext;
using EMS.Models;

namespace EMS.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly EmployeeDbContext _context;

        public EmployeeController(EmployeeDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            return View(await _context.Employee.ToListAsync());
        }

       
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = await _context.Employee
                .FirstOrDefaultAsync(m => m.ID == id);
            if (employee == null)
            {
                return NotFound();
            }

            return View(employee);
        }

        public IActionResult Create()
        {
            return View();
        }

   
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,Name,Email,Address,Phone,Salary,Gender,State,DateOfJoin,DateOfBirth,Age")] Employee employee)
        {
            if (ModelState.IsValid)
            {
                _context.Add(employee);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
     
      
            return View(employee);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = await _context.Employee.FindAsync(id);
            if (employee == null)
            {
                return NotFound();
            }
            ViewBag.States = new List<string>
             {
                 "Rajasthan",
                 "Uttar Pradesh",
                 "Maharashtra",
                 "Gujarat",
                 "Tamil Nadu",
                 "Karnataka",
                 "West Bengal",
                 "Punjab",
                 "Bihar",
              
             };
            return View(employee);
        }

      
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID,Name,Email,Address,Phone,Salary,Gender,State,DateOfJoin,DateOfBirth")] Employee employee)
        {
            if (id != employee.ID)
            {
                return NotFound();
            }

            if (employee.DateOfBirth != null)
            {
                var today = DateTime.Today;
                var age = today.Year - employee.DateOfBirth.Year;
                if (employee.DateOfBirth.Date > today.AddYears(-age)) age--;
                employee.Age = age;
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(employee);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EmployeeExists(employee.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }

            ViewBag.States = new List<string>
    {
        "Rajasthan", "Uttar Pradesh", "Maharashtra", "Gujarat", "Tamil Nadu",
        "Karnataka", "West Bengal", "Punjab", "Bihar", "New York"
    };

            return View(employee);
        }


        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = await _context.Employee
                .FirstOrDefaultAsync(m => m.ID == id);
            if (employee == null)
            {
                return NotFound();
            }

            return View(employee);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var employee = await _context.Employee.FindAsync(id);
            if (employee != null)
            {
                _context.Employee.Remove(employee);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool EmployeeExists(int id)
        {
            return _context.Employee.Any(e => e.ID == id);
        }

        [HttpPost]
        public IActionResult BulkDelete(int[] ids)
        {
            if (ids.Length == 0)
            {
                TempData["Error"] = "No records selected for deletion.";
                return RedirectToAction(nameof(Index));
            }

            var employeesToDelete = _context.Employee.Where(e => ids.Contains(e.ID)).ToList();

            if (employeesToDelete.Any())
            {
                _context.Employee.RemoveRange(employeesToDelete);
                _context.SaveChanges();
                TempData["Success"] = $"{employeesToDelete.Count} records deleted successfully.";
            }

            return RedirectToAction(nameof(Index));
        }
    }
}
